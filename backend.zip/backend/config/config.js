const config = {};
config.emailHost = "smtp.gmail.com";
config.emailUser = "quicktest2k20@gmail.com";
config.password = "QuickTest@123";
config.secret = "71fabac38a2396f8c1d23731d59b9c00";
config.clientId = "994242320378-ns2srgj1tmbrhtai5lmru4duv0kdi3l2.apps.googleusercontent.com";
config.clientsecret = "ob4a8sl7xEAgmT7iyOWVRxFy";
config.refreshToken = "1//04SOKbzhPcuTfCgYIARAAGAQSNwF-L9Ir2tmn1hIWuqnKH5N-cxj794-6C_tu8_ajJaFZteJNwvtx31lHR3BNACZtR4VtV0RqxAg";
/* module.exports = {
    secret :"71fabac38a2396f8c1d23731d59b9c00"
}; */
module.exports = config;

//Your Hash: 71fabac38a2396f8c1d23731d59b9c00
//Your String: theexamapmd5


//  994242320378-ns2srgj1tmbrhtai5lmru4duv0kdi3l2.apps.googleusercontent.com --client Id
//  ob4a8sl7xEAgmT7iyOWVRxFy --- client secret
//  4/tQF7isljlcJ9fev-T8sXv3pEQM9Hxn5CQ9COj5As3xhXYc65UFdLmj0lnsUDWQQkGWxopvHNJiMFQm-gU9UQ0vs  -- exchange code
//  1//04SOKbzhPcuTfCgYIARAAGAQSNwF-L9Ir2tmn1hIWuqnKH5N-cxj794-6C_tu8_ajJaFZteJNwvtx31lHR3BNACZtR4VtV0RqxAg   -- refresh token
//
