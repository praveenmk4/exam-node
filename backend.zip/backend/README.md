# Online Exam
	Online Exam for Skill-Set Testng

# Getting Started
	These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. See deployment for notes on how to deploy the project on a live system.

# Prerequisites
	Node-v12.13.0
	Npm -6.12.0
	MongoDb community edition
# Installing
	After cloning or downloading the project.
	# npm install
	will set up all the dependencies to your local machine

# Running the tests
	!!!
	Break down into end to end tests
	!!!

# Give an example
	!!!And coding style tests
	Explain what these tests test and why!!!

# Give an example
	Deployment
	Add additional notes about how to deploy this on a live system

# Versioning
	We use SemVer for versioning. For the versions available, see the tags on this repository.

# Authors
	Praveen Kumar Machavaram - Initial work 
	See also the list of contributors who participated in this project.

# License
	This project is licensed under the MIT License - see the LICENSE.md file for details

# Acknowledgments
  	!!!!!!!!!!
