const QuestionPaper = require('../models/questions-paper.model').QuestionPaper;
const async = require("async");
module.exports.getAllQuestions = (req, res) => {
    QuestionPaper.find({}, (err, Data) => {
        if (err) {
            res.send(err);
        } else if (Data == null) {
            res.send(`No tests are available`);
        } else {
            res.send(Data);
        }
    });
};