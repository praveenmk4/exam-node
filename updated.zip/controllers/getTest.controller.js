const GetTests = require('../models/get-test.model').GetTests;
const async = require("async");
module.exports.getAllTests = (req, res) => {
    GetTests.find({}, (err, Data) => {
        if (err) {
            res.send(err);
        } else if (Data == null) {
            res.send(`No tests are available`);
        } else {
            res.send(Data);
        }
    });
};