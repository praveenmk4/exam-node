const StartTest = require('../models/start-test.model').StartTest;
module.exports.createTest = (req, res) => {

    const createTest = {
        username: req.body.username,
        title: req.body.title,
        timeInSeconds: req.body.timeInSeconds,
        testGroup: req.body.testGroup,
        testType: req.body.testType,
        createdBy: req.body.createdBy
    };

    StartTest.findOne({
        username: createTest.username
    }).exec((err, Data) => {
        if (err) {
            res.send(err);
        } else if (Data !== null) {
            res.send(`test aleready exists with username ${createTest.username}`);
        } else {
            let test = {
                username: createTest.username,
                title: createTest.title,
                timeInSeconds: createTest.timeInSeconds,
                testGroup: createTest.testGroup,
                testType: createTest.testType,
                createdBy: ''
            }
            let newcreateTest = new StartTest(test);
            newcreateTest.save((error, result) => {
                if (error) {

                    res.send(error);
                } else {

                    res.send(result);
                }
            });
        }
    });
};