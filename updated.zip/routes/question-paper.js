var express = require('express');
var router = express.Router();
const GetQuestionPaper = require('../controllers/create-test.controller');
/* GET users listing. */
router.get('/getQuestionPaper', GetQuestionPaper.getQuestionPaper);
router.post('/updateQuestionPaper', GetQuestionPaper.updateQuestionPaper);

module.exports = router;