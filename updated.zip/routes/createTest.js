var express = require('express');
var router = express.Router();
const CreateTest = require('../controllers/create-test.controller');
/* GET users listing. */
router.post('/createTest', CreateTest.createTest);

module.exports = router;