var express = require('express');
var router = express.Router();
const GetTests = require('../controllers/getTests.controller');
/* GET users listing. */
router.get('/getTests', GetTests.GetTests);

module.exports = router;