const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const StartTestSchema = new mongoose.Schema({
    username: {
        type: String,
        required: true
    },
    title: {
        type: String,
        required: true
    },
    timeInSeconds: {
        type: Number,
        required: false
    },
    testGroup: {
        type: String,
        required: true
    },
    testType: {
        type: String,
        required: true
    },
    createdBy: {
        type: String,
        required: true
    }
});
const StartTestSchemaModel = mongoose.model('CreateTest', StartTestSchema);
module.exports = {
    CreateTest: StartTestSchemaModel
};