const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const QuestionPaperSchema = new mongoose.Schema({
    testId: {
        type: String,
        required: true
    },
    testTitle: {
        type: String,
        required: true
    },
    timeForTest: {
        type: Number,
        required: false
    },
    noOfQuestions: {
        type: Number,
        required: true
    },
    testType: {
        type: String,
        required: true
    },
    createdBy: {
        type: String,
        required: true
    },
    typeOfQuestion: {
        type: String,
        required: true
    },
    questions: [{
        questionId: {
            type: String,
            required: true
        },
        questionText: {
            type: String,
            required: true
        },
        questionGroup: {
            type: String,
            required: true
        },
        questionWeightage: {
            type: Number,
            required: false
        },
        questionType: {
            noOfOptions: {
                type: Number,
                required: false
            },
            correctAnswer: {
                type: Number,
                required: false
            },
            selectedAnswer: {
                type: Number,
                required: false
            },
            options: {
                option1: {
                    type: String,
                    required: false
                },
                option2: {
                    type: String,
                    required: false
                },
                option3: {
                    type: String,
                    required: false
                },
                option4: {
                    type: String,
                    required: false
                }
            }
        },
        compilerToBeUsed: {
            type: String,
            required: false
        },
        timeRequired: {
            type: String,
            required: false
        }
    }]
});
const QuestionPaperSchemaModel = mongoose.model('CreateTest', QuestionPaperSchema);
module.exports = {
    QuestionPaper: QuestionPaperSchemaModel
};